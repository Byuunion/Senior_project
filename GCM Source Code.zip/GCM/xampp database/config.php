<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "gcmdemo");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyAtxn-yYyPPgN0i4KlvI7w7AV8kGh0yn38"); // Place your Google API Key
?>